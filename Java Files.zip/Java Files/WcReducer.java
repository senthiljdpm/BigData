package mapred;

import java.io.IOException;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.Reducer.Context;

public class WcReducer extends Reducer <Text, Text, Text, Text>
{
	public void reduce(Text ang_rev, Iterable<Text> anag, Context context)
		      throws IOException, InterruptedException 
	{
			System.out.println("***************Inside Reducer**************");
	        Text result = new Text();		
			String temp =new String();
			for (Text t : anag)
			{
				temp = temp + "," + t.toString();
			}
			temp= temp.substring(1);
			result.set(temp);
			context.write(result, null); 
	}
}
