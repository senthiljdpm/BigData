package mapred_dna3b;

import java.io.IOException;
import java.util.Arrays;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class DNAMapper3b extends Mapper<Object, Text, Text, Text> 
{
	public void map(Object key, Text value, Context context) throws IOException, InterruptedException
	{
		
		String[] splt = value.toString().split("[ \t]+");
		// String Reverse
		StringBuilder str = new StringBuilder(splt[1]);
		str.reverse();
		String dna_rev = str.toString();

		Text user = new Text(splt[0]);
		Text dna = new Text(splt[1]);
		Text dna_rv = new Text(dna_rev);
		Text dna_fnl = new Text();
		
		if (dna.toString().compareTo(dna_rv.toString()) <0)
		{
			dna_fnl=dna;
		}
		else dna_fnl=dna_rv;
		
  		context.write(dna_fnl, user);
	}
}
