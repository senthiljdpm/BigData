package mapred;

import java.io.IOException;
import java.util.Arrays;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class WcMapper extends Mapper<Object, Text, Text, Text>
{
	public void map(Object key, Text Value, Context context) throws IOException, InterruptedException
	{
		
		String[] Ang = Value.toString().split("[ \t]+");
		String ang_rev;
		String ang_rev_sort;
		
		for (String anag: Ang)
		{
			//String Reverse		
			StringBuilder str = new StringBuilder(anag);
			str.reverse();
			ang_rev = str.toString();
			//Sort chars in string
			char[] chars = ang_rev.toCharArray();
			Arrays.sort(chars);
			ang_rev_sort = new String(chars);	
			
			context.write(new Text(ang_rev_sort), new Text(anag));
		}
	}
}
