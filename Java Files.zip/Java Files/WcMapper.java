package mapred;

import java.io.IOException;
import java.util.Arrays;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class WcMapper extends Mapper<Object, Text, Text, LongWritable>
{
	public void map(Object key, Text Value, Context context) throws IOException, InterruptedException
	{
		//String[] Ang = new String[] {"the", "cat", "act", "in", "tic", "tac", "toe"};
		String[] Ang = Value.toString().split("[ \t]+");
		for (int i =0; i< Ang.length; i++)
		{
			char[] chars = Ang[i].toCharArray();
			Arrays.sort(chars);
			String str = new String(chars);
			String temp="";
			for (int j =0; j< Ang.length; j++)
			{
				char[] charj = Ang[j].toCharArray();
				Arrays.sort(charj);
				String strj = new String(charj);
				
				if(str.equals(strj) && Ang[i] != Ang[j])
				{
						temp = temp + "," + Ang[j];
						Ang[j]="";
				}
			}
			String StrRed=Ang[i]  + temp;
			if (Ang[i]!="" || temp!="")
			  context.write(new Text(StrRed), new LongWritable(1));
	}
	}
}
