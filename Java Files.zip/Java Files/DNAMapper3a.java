package mapred_dna3a;

import java.io.IOException;
import java.util.StringTokenizer;
import java.util.Arrays;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class DNAMapper3a extends Mapper<Object, Text, Text, Text> 
{
	public void map(Object key, Text value, Context context) throws IOException, InterruptedException
	{
		
		String[] splt = value.toString().split("[ \t]+");
		
		Text user = new Text(splt[0]);
		Text dna = new Text(splt[1]);	
		
  		context.write(dna, user);
	
	}
}
