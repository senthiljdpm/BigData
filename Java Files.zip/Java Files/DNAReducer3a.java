package mapred_dna3a;

import java.io.IOException;
import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.Reducer.Context;

public class DNAReducer3a extends Reducer <Text, Text, Text, Text> 
{
	public void reduce(Text dna, Iterable<Text> user, Context context)
		      throws IOException, InterruptedException 
	{
		
		System.out.println("***************Inside Reducer**************");
        Text result = new Text();		
		String temp =new String();
		for (Text t : user)
		{
			temp = temp + "," + t.toString();
		}
		temp= temp.substring(1);
		result.set(temp);
		context.write(result, null);
	}
}
